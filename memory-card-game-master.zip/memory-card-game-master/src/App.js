import React from 'react';
import MemoryCardGame from './MemoryCardGame';

function App() {
  return React.createElement(MemoryCardGame);
}

export default App;
